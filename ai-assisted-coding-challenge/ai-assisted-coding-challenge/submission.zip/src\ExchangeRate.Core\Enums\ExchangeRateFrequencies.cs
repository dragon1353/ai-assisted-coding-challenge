namespace ExchangeRate.Core.Enums;

public enum ExchangeRateFrequencies
{
    Daily = 1,
    Monthly = 2,
    Weekly = 3,
    BiWeekly = 4
}
